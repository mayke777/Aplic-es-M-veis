export interface Pizzas {
    id: String;
    nome: String;
    codigo: String;
    ingrediente: String;
    preco: String;
    descricao: String;
}
